				/* Add Kaiser Permanente to the beta users list */
	            INSERT INTO MAT_APP_FAKE.STEWARD_ORG VALUES ('84', 'Kaiser Permanente','');
				INSERT INTO MAT_APP_FAKE.AUTHOR VALUES ('85', 'Kaiser Permanente');